import logging 
# from selenium.webdriver.remote.remote_connection import LOGGER 
# LOGGER.setLevel(logging.WARNING) 

# logging.basicConfig(filename="iris.log", format='%(asctime)s %(message)s', filemode='a+') 
# logger=logging.getLogger() 
# logger.setLevel(logging.DEBUG) 
def setup_logger(logger_name, log_file,m,level=logging.DEBUG):
    l = logging.getLogger(logger_name)
    formatter = logging.Formatter('%(asctime)s %(message)s')
    fileHandler = logging.FileHandler(log_file, mode=m)
    fileHandler.setFormatter(formatter)
    streamHandler = logging.StreamHandler()
    streamHandler.setFormatter(formatter)

    l.setLevel(level)
    l.addHandler(fileHandler)
    l.addHandler(streamHandler)

# def setup_logger2(logger_name, log_file, level=logging.DEBUG):
#     l = logging.getLogger(logger_name)
#     formatter = logging.Formatter('%(message)s')
#     fileHandler = logging.FileHandler(log_file, mode='a+')
#     fileHandler.setFormatter(formatter)
#     streamHandler = logging.StreamHandler()
#     streamHandler.setFormatter(formatter)

#     l.setLevel(level)
#     l.addHandler(fileHandler)
#     l.addHandler(streamHandler)

setup_logger('log1',"iris.log",'a+')
setup_logger('log2',"assign.log",'a+')
setup_logger('log3','error.log','a+')
setup_logger('log4','Unassigned.log','a+')
logger= logging.getLogger('log1')
logger1 = logging.getLogger('log2')
logger2 = logging.getLogger('log3')
logger3 = logging.getLogger('log4')