import iris
import mail
import configparser
from selenium.webdriver.chrome.options import Options
from logger import logger, logger2
from webElements import ReportPage, TaskPage
import myCSV
import time
import os
# from bs4 import BeautifulSoup
import pandas as pd
import Sharepoint
from selenium.common.exceptions import NoSuchElementException
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
import encryption

try:

	logger.debug('LOADING config.config file from same location as the exe.')
	config = configparser.ConfigParser()
	config.read(r'config.config')
	selenium_driver = config.get('file-paths', 'selenium_driver_path').replace('\\','/')
	download_path = config.get('file-paths', 'default_download_path')
	username = config.get('user-iris-bot-credential', 'iris_username')
	password = encryption.decrypt_password('user-iris-bot-credential','iris_key','iris_encrypt')
	# username = config.get('user-credentials', 'username')
	# password = config.get('user-credentials', 'password')
	sheet_name = config.get('auxiliary', 'sheet_name')
	headless = config.get('auxiliary', 'headless')
	logger.debug('SUCCESS! Read from config.config. ')


	roster_path = download_path+'/LTI_Shift Roaster_Draft.xlsx'
	keyword_path = download_path+'/keywords.xlsx'
	incident_path = download_path+'/incident.csv'
	task_path2 = download_path+'/sc_task.csv'

	time_to_wait = 80
	time_counter = 0


	if(os.path.exists(roster_path)):
		os.remove(roster_path)
	if(os.path.exists(keyword_path)):
		os.remove(keyword_path)
	if(os.path.exists(incident_path)):
		os.remove(incident_path)
	if(os.path.exists(task_path2)):
		os.remove(task_path2)			


	if headless in ['True', 'T', 1, 'true','t']:
		driver = iris.start_browser(selenium_driver,download_path,headless=True)
	else:
		driver = iris.start_browser(selenium_driver,download_path,headless=False)

	Sharepoint.download_files(driver,'config.config')

	roster_path = download_path+'/LTI_Shift Roaster_Draft.xlsx'
	keyword_path = download_path+'/keywords.xlsx'

	while not os.path.exists(roster_path) or not os.path.exists(keyword_path):
		time.sleep(2)
		time_counter += 1
		if time_counter > time_to_wait:
			break

	
	iris.login(driver,username,password)
	# WebDriverWait(driver,60).until(EC.presence_of_element_located((By.XPATH,'/html/body/div/section/header/div/div[2]/nav/div[2]/ul[1]/li/center/div/ul/li[1]/a')))
	time.sleep(10)

	logger.info('Login successful.')
	


	for report_link in ReportPage.task_links:
		driver.get(report_link)
		# time.sleep(3)

	for report_link in ReportPage.incident_links:
		driver.get(report_link)
		# time.sleep(5)


	while not os.path.exists(incident_path) or not os.path.exists(task_path2):
		time.sleep(2)
		time_counter += 1
		if time_counter > time_to_wait:
			break

	print("Files Downloaded")

	task_df = pd.read_csv('sc_task.csv',encoding='ISO-8859-1')
	incident_df = pd.read_csv('incident.csv',encoding='ISO-8859-1')

	open('Unassigned.log', 'w').close()
	open('assign.log', 'w').close()

	myCSV.assign_tasks(incident_df,task_df, 'LTI_Shift Roaster_Draft.xlsx', 'keywords.xlsx',driver,sheet_name,False)


	myCSV.assign_incidents(incident_df,task_df,'LTI_Shift Roaster_Draft.xlsx','keywords.xlsx',driver,sheet_name,False)
	
	mail.sendMail_Unassigned()
	iris.stop_browser(driver)
except TimeoutException as ex:
	logger2.exception(ex)
	mail.sendMail_Login()
	iris.stop_browser(driver)
except Exception as e:
	logger2.exception(e)
	mail.sendMail_Exception()
	iris.stop_browser(driver)



