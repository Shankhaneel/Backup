# Library imports.

import configparser
import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
from selenium.webdriver.support.select import Select 
# Local imports. 
from webElements import LogInPage, LogOutPage, IncidentPage, TaskPage
from logger import logger
from selenium.webdriver.common.action_chains import ActionChains
import pyautogui
import configparser
from selenium.webdriver.common.by import By
# from webdriver_manager.chrome import ChromeDriverManager
import encryption

# from webdriver_manager.chrome import ChromeDriverManager
pyautogui.FAILSAFE = False

def start_browser (path_to_driver_exe,download_path,headless):
	if headless:
		options = Options()
		options.headless = True
		options.add_argument('--log-level=3')
		options.add_argument('--incognito')
		logger.debug('Loading driver from '+path_to_driver_exe)
		driver = webdriver.Chrome(path_to_driver_exe,options=options)
		# driver = webdriver.Chrome(ChromeDriverManager().install(),options = options)
		driver.command_executor._commands["send_command"] = ("POST", '/session/$sessionId/chromium/send_command')
		params = {'cmd': 'Page.setDownloadBehavior', 'params': {'behavior': 'allow','downloadPath': download_path}}
		command_result = driver.execute("send_command", params)
		logger.info('Headless Web Driver initiated from: '+path_to_driver_exe)
		return (driver)
	else:
		options = Options()
		options.add_experimental_option("prefs", {
		  "download.default_directory": download_path,
		  "download.prompt_for_download": False
		  # "profile.default_content_setting_values.notifications" : 2
		})
		logger.debug('Loading driver from '+path_to_driver_exe)
		driver = webdriver.Chrome(path_to_driver_exe,options=options,service_log_path='NUL')
		logger.info('GUI based Web Driver initiated from: '+path_to_driver_exe)
		return(driver)

def stop_browser (driver):
	logger.debug('Closing browser.')
	driver.quit()
	logger.debug('Closed browser.')

def login(driver, lnt_username, lnt_password):
	config = configparser.ConfigParser()
	config.read(r'config.config')
	logger.debug('Logging in.')
	driver.get(LogInPage.login_link)
	time.sleep(5)
	pyautogui.press('escape')
	time.sleep(2)
	username = driver.find_element_by_id('username')
	username.send_keys(lnt_username)
	time.sleep(1)
	password = driver.find_element_by_id('password')
	password.send_keys(lnt_password)
	time.sleep(2)
	signon = driver.find_element_by_id('signOnButton').click()
	time.sleep(3)
	
	

def logout(driver):
	logger.debug('Logging out.')
	driver.get(LogOutPage.logout_link)
	logger.debug('Logged out.')

def iris_assign_incident(driver,incident,resource,bool_save,auto_close,cm,skill,inc_assign_group,ci_inc, caller):
	driver.get('https://link'+incident)
	#assign_to = driver.find_element_by_id(IncidentPage.id_assign_to)
	time.sleep(5)
	assign_to = driver.find_element_by_id('sys_display.incident.assigned_to')
	save = driver.find_element_by_id(IncidentPage.id_save_button)
	# print (auto_close)
	if bool_save:
		


		if skill == 'Sample':

			assign_group = driver.find_element_by_id('sys_display.incident.assignment_group')
			assign_group.clear()
			assign_group.send_keys('Sample')
			time.sleep(2)
			assign_group.send_keys(Keys.DOWN)
			assign_group.send_keys(Keys.RETURN)			

		
		
		time.sleep(2)
		# driver.execute_script("arguments[0].click();", assign_to)
		driver.implicitly_wait(10)
		ActionChains(driver).move_to_element(assign_to).click(assign_to).perform()

		time.sleep(1)
		assign_to.click()
		assign_to.clear()
		assign_to.send_keys(resource[:-1])
		time.sleep(5)
		assign_to.send_keys(Keys.DOWN)
		assign_to.send_keys(Keys.RETURN)
		time.sleep(2)
		if('Moogsoft' in caller):
			inc_loc = driver.find_element_by_id('sys_display.incident.location')
			inc_loc.clear()
			time.sleep(1)
			inc_loc.send_keys('1003 ROUTE 202 NORTH')
			time.sleep(2)

		if cm:
			if auto_close:
				Select(driver.find_element_by_id('incident.state')).select_by_index(3)
				time.sleep(2)
				# if('Moogsoft' in caller):
				# 	driver.find_element_by_id('sys_display.incident.location').send_keys('1003 ROUTE 202 NORTH')
				# 	time.sleep(2)
				resolution = driver.find_element_by_xpath("//span[text() = 'Resolution']")
				driver.implicitly_wait(10)
				ActionChains(driver).move_to_element(resolution).click(resolution).perform()
				time.sleep(1)


				driver.find_element_by_id('incident.close_notes').send_keys('Issue - This alert has been generated due to job failure. Root Cause - This alert has been generated as part of Auto Netcool alert.')
				time.sleep(2)

				# Select(driver.find_element_by_id('incident.u_breached_reason_code')).select_by_visible_text("Change Implementation")
				# time.sleep(2)

				Select(driver.find_element_by_id('incident.close_code')).select_by_visible_text("No Resolution Action")
				time.sleep(2)

				Select(driver.find_element_by_id('incident.u_resolution_sub_code')).select_by_visible_text("Resolved without intervention")
				time.sleep(2)

				# a=driver.find_element_by_id('sys_display.incident.u_resolution_category')
				# a.send_keys("Job Failure")
				# time.sleep(2)
				# a.send_keys(Keys.DOWN)
				# a.send_keys(Keys.RETURN)
				# time.sleep(2)
				driver.find_element_by_xpath("//span[text() = 'Log']").click()
				time.sleep(1)
				driver.find_element_by_id('activity-stream-textarea').send_keys('Issue - This alert has been generated due to job failure. Root Cause - This alert has been generated as part of Auto Netcool alert.')
				time.sleep(2)
				# if('Moogsoft' in caller):					
				# 	stats = driver.find_element_by_xpath("//span[text() = 'Stats']")
				# 	driver.implicitly_wait(10)
				# 	ActionChains(driver).move_to_element(stats).click(stats).perform()
				# 	time.sleep(1)
				# 	driver.find_element_by_id('sys_display.incident.u_owned_by_group').send_keys('ERP RR LTI')
				# 	time.sleep(2)
		else:		
			resolution = driver.find_element_by_xpath("//span[text()='Resolution']")
			driver.implicitly_wait(10)
			ActionChains(driver).move_to_element(resolution).click(resolution).perform()
			time.sleep(2)
			res_notes = driver.find_element_by_id('incident.close_notes')
			res_notes.clear()
			driver.implicitly_wait(10)
			ActionChains(driver).move_to_element(res_notes).click(res_notes).perform()
			time.sleep(2)
			if 'xxxxx' in ci_inc.lower():
				res_notes.send_keys('1.Detailed description of the Issue :')
				time.sleep(3)
				res_notes.send_keys(Keys.ENTER)
				
			else:
				res_notes.send_keys('1.Resolution Category : ')
				time.sleep(3)
				res_notes.send_keys(Keys.ENTER)
				res_notes.send_keys('2.Detailed description of Issue :')
				time.sleep(2)
				res_notes.send_keys(Keys.ENTER)
				res_notes.send_keys('3.Root Cause :')
				

		try:
			save.click()
		except :
			print('exception occurred, assign manually') 
			
def iris_assign_task(driver,task,resource,bool_save,skill,ci_task,det,autoWaiting):
	# logic removed similar to assign INC
	pass
def get_task_detail(task_id, driver):
	driver.get('https://link='+task_id)
	time.sleep(20)
	print("variable tab")
	varibles_tab = driver.find_element_by_xpath("/html/body/div[2]/form/div[1]/span[3]/span[1]/span[2]")
	time.sleep(4)
	ActionChains(driver).move_to_element(varibles_tab).click(varibles_tab).perform()
	time.sleep(2)
	varys = driver.find_element_by_xpath('/html/body/div[2]/form/span[4]/span/div/div/div/div[2]/table')
	soup = BeautifulSoup(varys.get_attribute('innerHTML'),'html.parser')
	ret_str = ','.join([str(i.get('value')) for i in soup.find_all('input')]+[str(i.get_text()) for i in soup.find_all('option',{"selected": "SELECTED"})])
	print("$$$$inside get task details")
	print(ret_str)
	return (ret_str)

def set_on_waiting(task_id, driver:webdriver):
    driver.get('https://link='+task_id)
    wait = WebDriverWait(driver,500)
    time.sleep(15)
    print("switching frame")
    driver.switch_to.frame(wait.until(EC.presence_of_element_located((By.ID,"gsft_main"))))
    ola =Select(wait.until(EC.presence_of_element_located((By.ID,"sc_task.u_ola_duration"))))
    sla=ola.first_selected_option.text
    print(sla)
    # OLA 1 Business Day(8-5)
    if("OLA 1 Business Day" in sla):
        # print("yes")
        task_state = Select(wait.until(EC.presence_of_element_located((By.ID,"sc_task.state"))))
        task_state.select_by_visible_text("Waiting on Customer")
        # print("waiting")
        time.sleep(10)
        while True:
            try:
                task_status = wait.until(EC.presence_of_element_located((By.ID,"sc_task.u_status")))
                task_status.click()
                task_status.send_keys(Keys.DOWN, Keys.RETURN)
                break
            except Exception as e:
                print("error")
                continue
        a = driver.find_element_by_xpath("//span[text() = 'Activity']")
        a.click()
        notes=wait.until(EC.presence_of_element_located((By.ID,TaskPage.id_notes)))
        notes.send_keys('Pending Prerequisites')
        save = driver.find_element_by_id(TaskPage.id_save_button)
        save.click()
