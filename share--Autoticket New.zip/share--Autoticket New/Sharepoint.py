import iris
import configparser
import time
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pyautogui
import encryption


def download_files(driver, sharepoint_config):
	config = configparser.ConfigParser()
	config.read(sharepoint_config)
	lnt_username = config.get('user-sharepoint-credentials', 'lnt_username')
	lnt_password = encryption.decrypt_password('user-sharepoint-credentials','lnt_key','lnt_encrypt')
	
	
	driver.get('https://link/teams/itasjde/_layouts/15/download.aspx?UniqueId=8efee2fb%2Db186%2D4e48%2Db0ed%2Dae07e72587b2')
	time.sleep(6)

	email_field = driver.find_element_by_id('i0116')
	print('after finding email field')
	email_field.send_keys(lnt_username)
	time.sleep(5)
	email_field.send_keys(Keys.RETURN)
	time.sleep(8)

	pyautogui.press('escape')
	time.sleep(25)
	email = driver.find_element_by_name('pf.username')
	email.send_keys(lnt_username)
	time.sleep(1)
	password = driver.find_element_by_name('pf.pass')
	password.send_keys(lnt_password)
	time.sleep(2)
	signon = driver.find_element_by_id('signOnButton').click()
	time.sleep(10)
	# no_button = driver.find_element_by_id('idBtn_Back')
	no_button = driver.find_element_by_xpath("/html/body/div/form/div/div/div[2]/div[1]/div/div/div/div/div/div[3]/div/div[2]/div/div[3]/div[2]/div/div/div[1]")
	no_button.click()
	time.sleep(5)

	# password_field = driver.find_element_by_id('passwordInput')
	# password_field.send_keys(lnt_password)
	# password_field.send_keys(Keys.RETURN)
	# time.sleep(5)


	driver.get('https://link/teams/itasjde/_layouts/15/download.aspx?UniqueId=222d6456%2D2db7%2D46ed%2Dab7c%2D2aabfc5adffe')
	time.sleep(5)

# driver = webdriver.chrome(ChromeDriverManager().install())
# config = configparser.ConfigParser()
# config.read(r'config.config')

# a = download_files(driver,'config.config')
# print(a)

