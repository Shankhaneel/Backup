import pandas  as pd 
from datetime import timedelta, datetime
import random 
import iris
from logger import logger1, logger3
from itertools import compress
from pytz import timezone


def get_queue_count(resources,incident_df,task_df):
	# incident_df = pd.read_csv('incident.csv',encoding='ISO-8859-1')
	# task_df = pd.read_csv('sc_task.csv',encoding='ISO-8859-1')
	count = dict(zip(resources, [0]*len(resources)))
	for i in incident_df.index:
		if incident_df['assigned_to'][i] == incident_df['assigned_to'][i]:
			res = incident_df['assigned_to'][i].split('(')[0].strip().title()
			res_count = res.lower()
			if res_count in resources:
				count[res_count] += 1
	for i in task_df.index:
		if task_df['assigned_to'][i] == task_df['assigned_to'][i]:
			res = task_df['assigned_to'][i].split('(')[0].strip().title()
			res_count = res.lower()
			if res_count in resources:
				count[res_count] += 1			
	return (count)

def get_date(delta):
	tz = timezone("Asia/Kolkata")
	r = datetime.strptime((datetime.now(tz)+timedelta(days=delta)).strftime("%Y-%m-%d"),'%Y-%m-%d')
	return r

# This function is hard coded. 
def get_current_shifts ():
	shifts = []
	shifts_ = []
	tz = timezone("Asia/Kolkata")
	hour = datetime.now(tz).hour
	print(hour)
	delta = 0
	if (hour < 21) and (hour >= 12):
		shifts += ['Gxxxxxx']
		shifts_ += ['Shift 2','xxxxx']
	if (hour < 3) or (hour >= 18):
		delta = -1 if hour < 3 else 0
		shifts += ['Gxxxxx']
		shifts_ += ['Shift 1']
	
	return (shifts, delta, shifts_)

def find_suitable_resource(i, roster_df, keyword_df, incident_df,task_df):
	inc_ci = incident_df['cmdb_ci'][i]
	inc_detail = str(incident_df['description'][i] )
	concerned_keyword_df = keyword_df[keyword_df['CI']==inc_ci]
	# Keyword in logger	
	match='none' 
	resource=''
	skill = 'none'
	site = ['Both']
	auto_close = False
	controlm_df = ''
	matched_key=''
	inc_assign_group = incident_df['assignment_group'][i]
	if (incident_df['assignment_group'][i] == 'XXXSX' or incident_df['XXXXXX'][i] == 'JXXXXXX'):
		skill = 'JDE - CNC'
	else:	
		for i in concerned_keyword_df.index:
			key_list = [list(map(lambda s: s.strip().lower(), i.strip().split('&'))) for i in concerned_keyword_df['keyword'][i].split('+')]
			if any(all([key in inc_detail.lower() for key in keys]) for keys in key_list):
				temp = [[all(key in inc_detail.lower() for key in keys)] for keys in key_list]
				print (list(compress(key_list, [i[0] for i in temp])))
				matched_key=list(compress(key_list, [i[0] for i in temp]))

				match=key_list
				skill = concerned_keyword_df['Technology/Skill'][i]
				site += [concerned_keyword_df['Site'][i]]
				auto_close = concerned_keyword_df['AutoClose'][i]
				controlm_df = keyword_df['Control-M'][i]
				resource = concerned_keyword_df['Resource'][i]
				break

# resource  - from keywords file
	if resource == '':
		shifts, delta,shifts_ = get_current_shifts()

		date_head = get_date(delta)
		# print(date_head)
		concerned_roster_df_ = roster_df[roster_df['Technology/Skill'] == skill][['Name','Site',date_head]]
		# print(concerned_roster_df)
		concerned_roster_df = concerned_roster_df_[concerned_roster_df_['Site'].isin(site)][['Name','Site',date_head]]

		resources = concerned_roster_df.loc[concerned_roster_df[date_head].isin(shifts)]['Name'].values
		if len(resources) == 0:
			resources = concerned_roster_df.loc[concerned_roster_df[date_head].isin(shifts_)]['Name'].values
			# concerned_roster_df = roster_df[roster_df['Technology/Skill'] =='Monitoring'][['Name',date_head]]
			# resources = [i.title() for i in concerned_roster_df.loc[concerned_roster_df[date_head].isin(shifts)]['Name'].values]
		resources_count=resources	
		temp=0
		for r in resources:
			resources_count[temp]= r.lower()
			temp+=1	
		queue_count = get_queue_count(resources_count,incident_df,task_df)
		print(queue_count)
		if len(resources) != 0:
			min_count = min(queue_count.values())
			ret_resources = [r for r in resources if queue_count[r] == min_count]
			suitable_resource = random.choice(ret_resources)
		else:
			suitable_resource = resources
	else:
		suitable_resource=resource
	print('inci ',skill,'***',site)

	# min_count = min(queue_count.values())
	# ret_resources = [r for r in resources if queue_count[r] == min_count]
	#suitable_resource = random.choice(ret_resources)
	incident_df.loc[i,'assigned_to'] = suitable_resource
	return (suitable_resource,auto_close,match,controlm_df,skill,matched_key,inc_assign_group)

def assign_incidents(incident_df,task_df, roster_file, keyword_file,driver,sheet_name,bool_save):
	roster_df = pd.read_excel(roster_file,sheet_name=sheet_name,keep_default_na=False, na_values=[''])
	keyword_df = pd.read_excel(keyword_file,keep_default_na=False, na_values=['_'])
	for i in incident_df.index:
		# print(incident_df['number'][i])
		
		# if incident_df['number'][i] == 'INC000024611790':
		if pd.isna(incident_df['assigned_to'][i]):
			res,auto_close,match,cm,skill,matched_key,inc_assign_group = find_suitable_resource(i,roster_df,keyword_df,incident_df,task_df)
			bool_save=False
			if len(res) != 0:
				bool_save=True
			# Logger
				res=str(res)
				match=str(match)
				matched_key=str(matched_key)
				logger1.info('Skill - '+ skill + " " +incident_df['number'][i]+' Assigned '+incident_df['cmdb_ci'][i]+' to '+res+' keywords='+str(match.encode('utf-8'))+' matched keywords= '+str(matched_key.encode('utf-8')))
			else:
				logger3.info('Skill - '+ skill + " " + incident_df['number'][i]+' '+incident_df['cmdb_ci'][i]+' not assigned')	
			print (incident_df['number'][i],' Assigned ',incident_df['cmdb_ci'][i],' to ',res)
			ci_inc = incident_df['cmdb_ci'][i]
			iris.iris_assign_incident(driver,incident_df['number'][i],res,bool_save,auto_close,cm,skill,inc_assign_group,ci_inc,incident_df['caller_id'][i])

def find_suitable_resource_task(task_detail,i,incident_df,task_df,roster_df,keyword_df):
	number = task_df['number'][i]
	task_ci = task_df['cmdb_ci'][i]
	concerned_keyword_df = keyword_df[keyword_df['CI']==task_ci]
	resource=''
	match='none'
	skill = 'none'
	site = ['Both']
	auto_wait = False
	matched_key=''
	if (task_df['assignment_group'][i] == 'JXXXXX' or task_df['assignment_group'][i] == 'XXXXX'):
		skill = 'JDE - CNC'
	else:	
		for i in concerned_keyword_df.index:
			key_list = [list(map(lambda s: s.strip().lower(), i.strip().split('&'))) for i in concerned_keyword_df['keyword'][i].split('+')]
			if any(all([key in task_detail.lower() for key in keys]) for keys in key_list):
				temp = [[all(key in task_detail.lower() for key in keys)] for keys in key_list]
				# temp = [all([key in task_detail.lower() for key in keys]) for keys in key_list]
				#print(temp)
				# print (key_list[i for i in temp])
				print (list(compress(key_list, [i[0] for i in temp])))
				matched_key=list(compress(key_list, [i[0] for i in temp]))
				match=key_list
				print (key_list)

				skill = concerned_keyword_df['Technology/Skill'][i]
				site += [concerned_keyword_df['Site'][i]]
				# resource  - from keywords file
				resource = concerned_keyword_df['Resource'][i]
				auto_wait = concerned_keyword_df['AutoWaiting'][i]
				break

	if resource == '':
		shifts, delta,shifts_ = get_current_shifts()

		date_head = get_date(delta)
		concerned_roster_df_ = roster_df[roster_df['Technology/Skill'] == skill][['Name','Site',date_head]]
		concerned_roster_df = concerned_roster_df_[concerned_roster_df_['Site'].isin(site)][['Name','Site',date_head]]
		# print(concerned_roster_df_,'without shift')
		resources = concerned_roster_df.loc[concerned_roster_df[date_head].isin(shifts)]['Name'].values
		# if len(resources) == 0:
		# 	concerned_roster_df = roster_df[roster_df['Technology/Skill'] =='Monitoring'][['Name',date_head]]
		# 	resources = [i.title() for i in concerned_roster_df.loc[concerned_roster_df[date_head].isin(shifts)]['Name'].values]
		if len(resources) == 0:
			resources = concerned_roster_df.loc[concerned_roster_df[date_head].isin(shifts_)]['Name'].values

			# concerned_roster_df = roster_df[roster_df['Technology/Skill'] =='Monitoring'][['Name',date_head]]
			# resources = [i.title() for i in concerned_roster_df.loc[concerned_roster_df[date_head].isin(shifts)]['Name'].values]
		resources_count=resources
		temp=0
		for r in resources:
			resources_count[temp]= r.lower()
			temp+=1
		queue_count = get_queue_count(resources_count,incident_df,task_df)
		print(queue_count)
		if len(resources) != 0:
			min_count = min(queue_count.values())
			ret_resources = [r for r in resources if queue_count[r] == min_count]
			suitable_resource = random.choice(ret_resources)
		else:
			suitable_resource = resources

	else:
		suitable_resource = resource
	print('task ***',skill,'***',site)
	logger1.info('task ***',skill,'***',site)
	# queue_count = get_queue_count(resources,incident_df,task_df)
	# min_count = min(queue_count.values())
	# ret_resources = [r for r in resources if queue_count[r] == min_count]
	#suitable_resource = random.choice(ret_resources)
	print(suitable_resource)
	try:
		task_df.loc[i,'assigned_to'] = suitable_resource
	except:
		logger1.info("None is present to avoid error")
	
	return (suitable_resource,match,skill,matched_key,auto_wait)


def assign_tasks(incident_df,task_df, roster_file,keyword_file, driver,sheet_name,bool_save):
	roster_df = pd.read_excel(roster_file,sheet_name=sheet_name,keep_default_na=False, na_values=[''])
	keyword_df = pd.read_excel(keyword_file,keep_default_na=False, na_values=['_'])
	
	for i in task_df.index:
		print(task_df['number'][i])

		# if task_df['number'][i]=='TASK000024476611':
		# 	print("task TASK000023986418 found")
			# continue
		# print("inside task assignment")

		
		if pd.isna(task_df['cmdb_ci'][i]):
			task_df['cmdb_ci'][i] = 'NONE'
		if pd.isna(task_df['assigned_to'][i]):
			det = iris.get_task_detail(task_df['number'][i],driver)
			print("****det block****")
			print('Detail ',det)
			res,match,skill,matched_key,autoWaiting = find_suitable_resource_task(det,i,incident_df,task_df,roster_df, keyword_df)
			bool_save=False
			if len(res) != 0:				
				bool_save=True
				# Logger
				res=str(res)
				matched_key=str(matched_key)
				match=str(match)
				if task_df['cmdb_ci'][i] != 'NONE' :
					logger1.info('Skill - ' + skill + " " + task_df['number'][i]+' Assigned '+str(task_df['cmdb_ci'][i])+' to '+res+' keywords= '+str(match.encode('utf-8'))+' matched keywords= '+str(matched_key.encode('utf-8')))
				else :
					logger3.info('Skill - ' + skill + " " + task_df['number'][i]+' '+str(task_df['cmdb_ci'][i])+' C.I Updated')	
			else:
				logger3.info('Skill - ' + skill + " " + task_df['number'][i]+' '+str(task_df['cmdb_ci'][i])+' not assigned')	
			print(task_df['number'][i],' Assigned ',task_df['cmdb_ci'][i],' to ',res)
			ci_task = task_df['cmdb_ci'][i]		
			iris.iris_assign_task(driver,task_df['number'][i],res,bool_save,skill,ci_task,det,autoWaiting)

