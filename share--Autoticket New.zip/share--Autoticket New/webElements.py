class LogInPage():
	login_link = ''
	id_username = 'username'
	id_password = 'password'

class LogOutPage():
	logout_link = ''

class ReportPage():
	class_name_table = 'data_list_table'
	incident_links = ['']
	task_links = ['']

class IncidentPage():
	id_assign_to = 'sys_display.incident.assigned_to'
	id_save_button = 'sysverb_update'

class TaskPage():
	id_assign_to = 'sys_display.sc_task.assigned_to'
	id_save_button = 'sysverb_update'
	xpath_variable = "//span[text() = 'Variables']"
	# id_notes ='activity-stream-work_notes-textarea'
	id_notes ='activity-stream-textarea'