# from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import os
import os.path


SMTP_SERVER = r'SMTP.na.jnj.com'
fromaddr="TicketDispatcher@its.jnj.com"


def sendEmail(email_body,toaddr,cc,message_subject,filename):
    # _footer_html  = f"<br><br><br><br><br><br>Regards,<br><b><i><h4> Automation Team</h4></i></b>"
    # _footer_html += "<br><hr><u><b>This is an automated email notification, please do not reply</b></u>"
    # msg = MIMEText(email_body.replace('\n','<br>') + _footer_html, 'html')
    # rcpt = toaddr.split(",")

    # if cc != "None" and cc != "":
    #   rcpt = rcpt + cc.split(",")
    #   msg['Cc'] = cc
    
    # msg['Subject'] = message_subject
    # msg['To'] = toaddr
    # msg['From'] = fromaddr

    # # msg.attach(MIMEText(email_body,'html'))
    # for f in filename:
    #     attachment  =open(f,'rb')

    #     part = MIMEBase('application','octet-stream')
    #     part.set_payload((attachment).read())
    #     encoders.encode_base64(part)
    #     head, tail = os.path.split(f)
    #     print(tail)
    #     part.add_header('Content-Disposition','attachment', filename= tail)

    #     msg.attach(part)
    #     text = msg.as_string()

    # mail = smtplib.SMTP(SMTP_SERVER)
    # mail.starttls()
    # mail.sendmail(fromaddr, rcpt, msg.as_string())
    # mail.quit()
    msg = MIMEMultipart()

    rcpt = toaddr.split(",")

    if cc != "None" and cc != "":
      rcpt = rcpt + cc.split(",")
      msg['Cc'] = cc
    
    msg['Subject'] = message_subject
    msg['To'] = toaddr
    msg['From'] = fromaddr

    msg.attach(MIMEText(email_body,'html'))
    for f in filename:
        attachment  =open(f,'rb')

        part = MIMEBase('application','octet-stream')
        part.set_payload((attachment).read())
        encoders.encode_base64(part)
        head, tail = os.path.split(f)
        part.add_header('Content-Disposition','attachment', filename= tail)

        msg.attach(part)
        text = msg.as_string()


    mail = smtplib.SMTP(SMTP_SERVER)
    mail.starttls()
    mail.sendmail(fromaddr, rcpt, msg.as_string())
    mail.quit()
    