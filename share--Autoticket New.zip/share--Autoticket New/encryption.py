from cryptography.fernet import Fernet
import configparser

config = configparser.ConfigParser()
config.read(r'config.config')


def key_generation():
    key = Fernet.generate_key()
    print(key)
    


def encrypt_password():
    
    key = ''
    # print(key)

    # using the generated key
    fernet = Fernet(key)
    
    # opening the original file to encrypt
    original = ''
    
    # encrypting the file
    encrypted = fernet.encrypt(original.encode())
    
    print(encrypted)


def decrypt_password(path,key,encrypt):
    key = config.get(path,key)
    fernet = Fernet(key)
    encrypted = config.get(path,encrypt)
    decrypted = fernet.decrypt(encrypted.encode())
    decrypted_password = decrypted.decode()
    return decrypted_password


# if __name__=="__main__":
    # key_generation()
    # encrypt_password()
    # print(decrypt_jdepassword())
    # print(decrypt_password('user-iris-bot-credential','iris_key','iris_encrypt'))


