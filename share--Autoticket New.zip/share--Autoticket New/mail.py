# import win32com.client as win32
import os
import SMTPmail


# path = os.getcwd()
path = r"F:\Autoticket New"



def sendMail_Exception():
    toaddr = ''
    cc = ''
    # cc=''
    # toaddr = 'SMhashil@its.jnj.com'
    # cc=''
    email_body="""
    <P>Hi All,</P>

    <P>Error has occured. PFA Logs file</P>"""
    message_subject = 'ALERT! - Error has occured in Auto dispatcher tool'
    attachments=[]
    attachment1 = path+"/error.log"
    attachment2 = path+"/assign.log"
    attachments.append(attachment1)
    attachments.append(attachment2)
    SMTPmail.sendEmail(email_body,toaddr,cc,message_subject,attachments)

def sendMail_Unassigned():
    print("sending mail")
    toaddr = ''
    cc=''
    email_body="""
    <P>Hi All,</P>

    <P>Successful Run. PFA Logs files</P>"""
    message_subject = 'Auto Dispatcher - Successful Run'
    attachments=[]
    attachment1  = path+"/Unassigned.log"
    attachment2 = path+"/assign.log"
    attachments.append(attachment1)
    attachments.append(attachment2)
    SMTPmail.sendEmail(email_body,toaddr,cc,message_subject,attachments)

def sendMail_Login():
    print("sending mail")
    toaddr = ''
    # cc=''
    cc=''
    email_body="""
    <P>Hi All,</P>

    <P>Login Failed. Please Check Login Details</P>""" 
    message_subject = 'Login Failed'
    attachments=[]
    attachment1  = path+"/error.log"
    attachments.append(attachment1)
    SMTPmail.sendEmail(email_body,toaddr,cc,message_subject,attachments)

if __name__=="__main__":
    # sendMail_Login()
    # sendMail_Unassigned()
    sendMail_Exception()
